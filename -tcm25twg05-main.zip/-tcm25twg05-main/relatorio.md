
# Relatorio

## 1 Apresentação do projeto 

O trabalho tem como objetivo principal dar a conhecer dar a conhecer o que é a multimedia, as suas principais areas , os equipamentos e competencias necessarias para dominar a area

## Interface com o utilizador

Multimedia.pdf

Desing.pdf

Fotografia.pdf

Web.pdf

Map.site

## Produto

### Descrição do produto

Em relação ao primeiro tópico apresento uma pequena introdução sobre a multimédia, um pouco da sua história e as principais áreas que ela se insere de modo a dar um contexto do que o cliente pode esperar nas restantes paginas do site

Posteriormente passo a falar no design explicando mais aprofundadamente a que se refere que tipos de trabalhos e de competências são necessárias para conseguir trabalhar no meio

De seguida, centro a minha atenção na área da fotografia, esta pagina é a que tem mais informação porem a fotografia é algo que engloba muitas áreas e de ser maneira todas as áreas  da multimédia acabam por estar ligadas à fotografia. No final da página falo um pouco do cinema e atenção aos filmes premiados em 2025

Por último, decidi dedicar uma pagina a falar da web e da criação de sites, já que é o que estou a fazer para esta cadeira, não entro em muitos pormenores por ser uma área mais técnica e que exige mais pesquisa e aprendizagem para alguém entra no meio

O objeto do meu trabalho em suma é dar a conhecer as inúmeras áreas que a multimédia tem para oferecer e motivar o máximo de pessoas possível a entrarem para a nossa áre

### Instruções de instalação e configuração

Não é necessário qualquer tipo de instalação 

### Regras de utilização

Não é exigida nenhuma autentificação, qualquer utilizador apenas tem que ter acesso à internet e não tem qualquer tipo de restrição 
 
### Ajuda à navegação

O site tem os menus e todos elementos separados com um grande destaque de cor e com o espaçamento necessário entre eles

### Validações de formulários

xmlvalidator.png

### Validação do HTML e CSS

css validator.png

html.validator.png


### Detalhes de implementação

Cumpri quase todos os objetivos, não consegui resolver alguns erros que apareceram, tentei pesquisar mais porém não consegui mesmo resolver todos.

Tive muitas dificuldades no javascript, não conseguindo no final colocar o vídeo a dar 

O que gostei mais foi trabalhar com o css e com o html, assim como montar o site e ver ele a montar-se aos poucos 